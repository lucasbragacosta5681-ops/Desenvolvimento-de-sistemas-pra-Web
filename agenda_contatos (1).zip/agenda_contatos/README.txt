========================================
  AGENDA DE CONTATOS COM LOGIN - PHP
========================================

COMO USAR:
1. Coloque a pasta "agenda_contatos" em um servidor PHP
   (XAMPP, WAMP, Laragon, ou hospedagem).

2. Acesse pelo navegador:
   http://localhost/agenda_contatos/

3. Login padrão:
   Usuário: admin
   Senha:   123456

FUNCIONALIDADES:
- Login com senha segura (hash)
- Adicionar, editar e excluir contatos
- Cada usuário vê apenas seus contatos
- Banco SQLite (arquivo agenda.db é criado automaticamente)

ARQUIVOS:
- index.php     → Tela de login
- contacts.php  → Lista e formulário de contatos
- logout.php    → Sai do sistema
- db.php        → Conexão e criação do banco
- style.css     → Visual simples

REQUISITOS:
- PHP 7.4 ou superior (com extensão PDO SQLite)

Não precisa instalar MySQL. Tudo funciona com um único arquivo de banco.
