<?php
// contacts.php - Página principal da agenda
session_start();
require 'db.php';

// Proteção: só acessa se estiver logado
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$message = '';

// === ADICIONAR CONTATO ===
if (isset($_POST['action']) && $_POST['action'] === 'add') {
    $name  = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    if ($name) {
        $stmt = $pdo->prepare("INSERT INTO contacts (user_id, name, phone, email, notes) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $name, $phone, $email, $notes]);
        $message = 'Contato adicionado com sucesso!';
    } else {
        $message = 'O nome é obrigatório.';
    }
}

// === EDITAR CONTATO ===
if (isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id    = (int)($_POST['id'] ?? 0);
    $name  = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $notes = trim($_POST['notes'] ?? '');

    if ($id && $name) {
        $stmt = $pdo->prepare("UPDATE contacts SET name=?, phone=?, email=?, notes=? WHERE id=? AND user_id=?");
        $stmt->execute([$name, $phone, $email, $notes, $id, $user_id]);
        $message = 'Contato atualizado!';
    }
}

// === EXCLUIR CONTATO ===
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM contacts WHERE id=? AND user_id=?");
    $stmt->execute([$id, $user_id]);
    $message = 'Contato excluído!';
}

// Busca todos os contatos do usuário
$stmt = $pdo->prepare("SELECT * FROM contacts WHERE user_id = ? ORDER BY name");
$stmt->execute([$user_id]);
$contacts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Se estiver editando, pega os dados do contato
$edit_contact = null;
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM contacts WHERE id=? AND user_id=?");
    $stmt->execute([$id, $user_id]);
    $edit_contact = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Contatos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Agenda de Contatos</h1>
            <div class="user-info">
                Olá, <strong><?= htmlspecialchars($_SESSION['username']) ?></strong> |
                <a href="logout.php">Sair</a>
            </div>
        </header>

        <?php if ($message): ?>
            <div class="success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <!-- Formulário de Adicionar / Editar -->
        <div class="form-box">
            <h2><?= $edit_contact ? 'Editar Contato' : 'Novo Contato' ?></h2>
            <form method="POST">
                <input type="hidden" name="action" value="<?= $edit_contact ? 'edit' : 'add' ?>">
                <?php if ($edit_contact): ?>
                    <input type="hidden" name="id" value="<?= $edit_contact['id'] ?>">
                <?php endif; ?>

                <label>Nome *</label>
                <input type="text" name="name" required
                       value="<?= htmlspecialchars($edit_contact['name'] ?? '') ?>">

                <label>Telefone</label>
                <input type="text" name="phone"
                       value="<?= htmlspecialchars($edit_contact['phone'] ?? '') ?>">

                <label>E-mail</label>
                <input type="email" name="email"
                       value="<?= htmlspecialchars($edit_contact['email'] ?? '') ?>">

                <label>Observações</label>
                <textarea name="notes" rows="2"><?= htmlspecialchars($edit_contact['notes'] ?? '') ?></textarea>

                <button type="submit"><?= $edit_contact ? 'Salvar Alterações' : 'Adicionar Contato' ?></button>
                <?php if ($edit_contact): ?>
                    <a href="contacts.php" class="btn-cancel">Cancelar</a>
                <?php endif; ?>
            </form>
        </div>

        <!-- Lista de Contatos -->
        <h2>Meus Contatos (<?= count($contacts) ?>)</h2>

        <?php if (empty($contacts)): ?>
            <p class="empty">Nenhum contato cadastrado ainda.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Telefone</th>
                        <th>E-mail</th>
                        <th>Observações</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($contacts as $c): ?>
                        <tr>
                            <td><?= htmlspecialchars($c['name']) ?></td>
                            <td><?= htmlspecialchars($c['phone']) ?></td>
                            <td><?= htmlspecialchars($c['email']) ?></td>
                            <td><?= htmlspecialchars($c['notes']) ?></td>
                            <td class="actions">
                                <a href="?edit=<?= $c['id'] ?>" class="btn-edit">Editar</a>
                                <a href="?delete=<?= $c['id'] ?>" class="btn-delete"
                                   onclick="return confirm('Tem certeza que deseja excluir?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>
